bash run_s2g_bucket.sh s2g_bucket/0521/exp1
bash run_s2g_bucket.sh s2g_bucket/0521/exp2
bash run_s2g_bucket.sh s2g_bucket/0521/exp3
bash run_s2g_bucket.sh s2g_bucket/0521/exp4
bash run_s2g_bucket.sh s2g_bucket/0521/exp5

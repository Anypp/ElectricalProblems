bash run_s2gkg.sh s2gkg/0527/exp1
bash run_s2gkg.sh s2gkg/0527/exp2
bash run_s2gkg.sh s2gkg/0527/exp3
bash run_s2gkg.sh s2gkg/0527/exp4
bash run_s2gkg.sh s2gkg/0527/exp5
